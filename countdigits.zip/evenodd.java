public class evenodd {
   public static void taukif(){
    
  for(int i=1;i<21;i++)
  if (i%2==0) {
    System.out.println();
    System.out.println(i + " even");
  
  }
  else{
    System.out.println();
    System.out.println(i + " odd");
  }
}
public static void main(String[] args) {
  taukif();
} 
}
